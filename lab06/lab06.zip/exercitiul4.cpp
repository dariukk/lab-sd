#include "helpers.h"
#include "bst_node.h"

bst_node_t *lowest_common_ancestor(bst_node_t * const node1, bst_node_t * const node2) {
  return NULL;
}
